self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "71ab4b99fdcb87b971fc036e1625f228",
    "url": "/index.html"
  },
  {
    "revision": "340bb8a5e22d6b9904bd",
    "url": "/static/css/main.b6691e8c.chunk.css"
  },
  {
    "revision": "55cb90c55caa6ed01e99",
    "url": "/static/js/2.1636ade7.chunk.js"
  },
  {
    "revision": "27bbadeef7d02efcaae5fffc16c6b291",
    "url": "/static/js/2.1636ade7.chunk.js.LICENSE.txt"
  },
  {
    "revision": "340bb8a5e22d6b9904bd",
    "url": "/static/js/main.2e77b850.chunk.js"
  },
  {
    "revision": "68b22ded67f8c495116e",
    "url": "/static/js/runtime-main.5ebb85b7.js"
  }
]);